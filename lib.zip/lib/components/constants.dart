import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xff1B3A56);
const kMessage = 'message';
